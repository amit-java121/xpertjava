package com.xpert.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {
	
	@GetMapping("/")
	public String getLoginPage() {
		System.out.println("login");
		return "login";
	}
	
	@GetMapping("/customerLogin")
	public String getLogin(@RequestParam String customerName,@RequestParam String customerPassword) {
		System.out.println("login credentials: "+customerName+""+customerPassword);
		return "customerList";
	}

}
