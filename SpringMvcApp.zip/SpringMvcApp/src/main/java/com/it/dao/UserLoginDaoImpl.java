package com.it.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserLoginDaoImpl implements IUserLoginDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public User getUserDetails(String userEmail) {
		System.out.println("dao called"+userEmail);
		User user =  new User();
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from User where userEmail=:user_email");
		query.setParameter("user_email", userEmail);
		List userList = query.getResultList();
		if(userList!= null && userList.size() > 0) {
		  user = (User)userList.get(0);
		}
		System.out.println("user from db "+user.toString());
		
		return user;
	}

	@Override
	public boolean saveUser(User user) {

		Session session = sessionFactory.getCurrentSession();
		boolean flag = session.save(user) != null;
		
		return flag;
	}

	@Override
	public List<User> getUserdetailsFrmDb() {

		Session session = sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		
		return (List<User>)criteria.list();
		
	}

}
