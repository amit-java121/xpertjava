package com.it.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;
import com.it.service.UserLoginServiceImpl;

@Repository
public class UserLoginDaoImpl implements IUserLoginDao{

	Logger log = Logger.getLogger(UserLoginDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public User getUserDetails(String userEmail) {
		System.out.println("dao called"+userEmail);
		User user =  new User();
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from User where userEmail=:user_email");
		query.setParameter("user_email", userEmail);
		List userList = query.getResultList();
		if(userList!= null && userList.size() > 0) {
		  user = (User)userList.get(0);
		}
		System.out.println("user from db "+user.toString());
		
		return user;
	}

	@Override
	public boolean saveUser(User user) {
		boolean flag =true;
		Session session = sessionFactory.getCurrentSession();
		   try {
		   session.saveOrUpdate(user);	
		   }catch(Exception e) {
			   flag =false; 
		   }
		return flag;
	}

	@Override
	public List<User> getUserdetailsFrmDb() {

		Session session = sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		
		//criteria.add(Restrictions.lt("salary", 20000));
		//criteria.setProjection(Projections.avg("id"));
		
		return (List<User>)criteria.list();
		
	}

	@Override
	public User editUser(String id) {
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, Integer.valueOf(id));
		return user;
	}

	@Override
	public boolean delete(int id) {
		log.info("delete method executed::");
		boolean flag=true;
		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, id);
		try {
		session.delete(user);
		}catch(Exception e) {
			flag=false;
			e.printStackTrace();
			log.error("Error UserLoginDaoImpl.delete() "+e);
		}
		
		return flag;
	}

}
