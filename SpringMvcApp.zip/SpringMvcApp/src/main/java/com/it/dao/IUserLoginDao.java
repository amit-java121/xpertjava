package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface IUserLoginDao {

	public User getUserDetails(String userEmail);
	public boolean saveUser(User user);
	public List<User> getUserdetailsFrmDb();
}
