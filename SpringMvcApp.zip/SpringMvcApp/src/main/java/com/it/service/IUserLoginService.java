package com.it.service;

public interface IUserLoginService {
	public void userDetails(String userEmail,String password);
}
