package com.it.service;

public interface IUserLoginService {
	public boolean userDetails(String userEmail,String password);
}
