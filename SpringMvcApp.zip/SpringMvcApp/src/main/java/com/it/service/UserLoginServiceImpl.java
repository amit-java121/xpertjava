package com.it.service;

import org.springframework.stereotype.Service;

@Service
public class UserLoginServiceImpl implements IUserLoginService{

	@Override
	public void userDetails(String userEmail, String password) {
		System.out.println("we are in service class "+userEmail+" pass "+password);
		//UI user name
		//DB user name password
		//compare validate 
		////logic
		
	}

}
