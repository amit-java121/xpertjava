package com.it.service;

import java.util.List;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.controller.LoginController;
import com.it.dao.IUserLoginDao;
import com.it.model.User;

@Service
@Transactional
public class UserLoginServiceImpl implements IUserLoginService{
	
	Logger log = Logger.getLogger(UserLoginServiceImpl.class);

	@Autowired
	IUserLoginDao iUserLoginDao;
	
	@Override
	public boolean userDetails(String userEmail, String password) {
		boolean flag=false;
		System.out.println("we are in service class "+userEmail+" pass "+password);
		//UI user name
		//DB user name password
		//compare validate 
		////logic
		User user = iUserLoginDao.getUserDetails(userEmail);
		
		if(userEmail.equalsIgnoreCase(user.getUserEmail()) && password.equalsIgnoreCase(user.getPassword())) {
		 flag = true;
		}else {
		 flag=false;
		}
		
		return flag;
	}

	@Override
	public boolean saveUser(User user) {
		
		return iUserLoginDao.saveUser(user);
	}

	@Override
	public List<User> getUserDeatisl() {

		List<User> userlist = iUserLoginDao.getUserdetailsFrmDb();
		return userlist;
		
	}

	@Override
	public User editUser(String id) {

		return iUserLoginDao.editUser(id);
		
	}

	@Override
	public boolean delete(int id) {
		log.info("user object deleted!!!");
		return iUserLoginDao.delete(id);
	}

}
