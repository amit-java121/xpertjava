package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.IUserLoginService;

@Controller
public class LoginController {
	
	@Autowired
	IUserLoginService userLoginService;
	
	@GetMapping("/")
	public String login() {
		System.out.println("inside login method::: ");
		
		return "login";
	}
	
	@GetMapping("/login")
	public void getLoginDetails(@RequestParam("userEmail") String userEmail,@RequestParam("password") String password) {
		System.out.println("userEmail:: "+userEmail);
		System.out.println("password:: "+password);
		userLoginService.userDetails(userEmail, password);
	}

}
