package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.IUserLoginService;

@Controller
public class LoginController {
	
	@Autowired
	IUserLoginService userLoginService;
	
	@GetMapping("/")
	public String login() {
		System.out.println("inside login method::: ");
		return "login";
	}
	
	@GetMapping("/login")
	public String getLoginDetails(@RequestParam("userEmail") String userEmail,@RequestParam("password") String password,Model model) {
		System.out.println("userEmail:: "+userEmail);
		System.out.println("password:: "+password);
		boolean flag = userLoginService.userDetails(userEmail, password);
		
		if(flag) {
			return "redirect:/getUser";
			
		}else {
			model.addAttribute("msg", "your user name password is wrong please try again::");
			return "login";
		}

	}
	
	@GetMapping("/user-form")
	public ModelAndView getUserPage() {
		
		ModelAndView model = new ModelAndView("userForm");
		model.addObject("user", new User());
		return model;
	}
	
	@PostMapping("/save")
	public String saveUserDetails(@ModelAttribute User user) {
		System.out.println(user.toString());
		boolean flag = userLoginService.saveUser(user);
		if(flag) {
			System.out.println("success::: ");
			return "redirect:/getUser";
		}else {
			return "userForm";
		}
	}
	
	
	@GetMapping("/getUser")
	public ModelAndView getUserDetails() {
		ModelAndView model = new ModelAndView("userDetails");
		List<User> userList = userLoginService.getUserDeatisl();
		System.out.println("list ::"+userList.toString());
		model.addObject("list", userList);
		return model;
	}
	
	@GetMapping("/edit")
	public ModelAndView editUserDetails(@RequestParam("id") String id) {
		System.out.println("user id:: "+id);
		User user = userLoginService.editUser(id);
		ModelAndView model = new ModelAndView("userForm");
		model.addObject("user", user);
		System.out.println("controller: "+user.toString());
		return model;
	}
	
	@GetMapping("/delete")
	public String deleteUser(@RequestParam("id") int id,Model model) {
		System.out.println("delete "+id);
		boolean flag = userLoginService.delete(id);
		if(flag) {
			return "redirect:/getUser";
		}else {
			model.addAttribute("msg", "Record is not deleted!!");
			return "login";
		}
	}

}
