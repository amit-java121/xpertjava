
public class AA {
	
	AA m1() {
		
	return this;
	}
	
	void m2() {
		AA aa = m1();
		System.out.println(aa);
	}
	
	public static void main(String[] args) {
		AA aa = new AA();
		aa.m2();
	}

}
