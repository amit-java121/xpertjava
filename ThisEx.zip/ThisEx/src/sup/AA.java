package sup;

public class AA extends BB{
	
	public AA() {
	   super(10);
		System.out.println("default");
	}
	
	public static void main(String[] args) {
		AA aa = new AA();
		
	}

}
