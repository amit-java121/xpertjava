package sup;

public class B {
	int aa=20;
	
	void m2() {
		System.out.println("m2 of class B");
	}
	
	void xyz() {
		System.out.println("xyz of class B");
	}

}
