package sup;

public class A extends B{
	
	int aa=10;
	
	void m1() {
		super.m2();
		xyz();
		//System.out.println(aa);
		//System.out.println(super.aa);
	}
	
	void m2() {
		System.out.println("m2 of class A");
	}
	
	public static void main(String[] args) {
		A a = new A();
		a.m1();
	}

}
