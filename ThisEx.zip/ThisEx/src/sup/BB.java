package sup;

public class BB {

	public BB(int a) {
		System.out.println("param super class "+a);
	}
	
	public BB() {
		System.out.println("default BB");
	}
}
