
public class B {
	
	void m1() {
		System.out.println("m1 class B");
	}

}
