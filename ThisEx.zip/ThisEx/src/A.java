
public class A extends B{
	
	public A() {
		this(10);
		System.out.println("default const:::");
		
	}
	
	public A(int a) {
		System.out.println("param const:::");
	}
	
	
	
	void m1() {
		System.out.println("called m1():: ");
	}
	
	void m2() {
		this.m1();
	}
	
	
	public static void main(String[] args) {
		A a = new A();
		//a.m2();
	}
	

}
