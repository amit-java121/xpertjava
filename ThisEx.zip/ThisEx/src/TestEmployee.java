
public class TestEmployee {
	
	public static void main(String[] args) {
		 
		Employee emp = new Employee(100, "xpert", "pune");
		
		System.out.println(emp.toString());
	}

}
