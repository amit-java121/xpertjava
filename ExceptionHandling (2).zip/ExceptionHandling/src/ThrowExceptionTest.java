
public class ThrowExceptionTest {
	
	public void m2() {
		String name="xpert";
		
		if(name.equalsIgnoreCase("xpert")) {
			throw new IllegalArgumentException(" this is java class ");
		}
	}
	
	public static void main(String[] args) {
		ThrowExceptionTest te = new ThrowExceptionTest();
		try {
		te.m2();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
