
public class A {
	
	public void test() throws Exception {
		System.out.println("A test() ");
	}

}
