
public class TestException {
	
	public void m1() throws CustomException {
		String name="xpert";
		if(name.equalsIgnoreCase("xpert")) {
			throw new CustomException(" this is java class ",400);
		}
	}
	
	public static void main(String[] args) {
		TestException te = new TestException();
		try {
		te.m1();
		}catch(CustomException ce) {
			System.out.println(ce.getMessage()+"error code "+ce.getErrorCode());
		}
	}

}
