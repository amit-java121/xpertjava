
public class B extends A{

	public void test() throws NullPointerException{
		System.out.println("B test() ");
	}
	
	public static void main(String[] args) {
		 B b = new B();
		 b.test();
	}
}
