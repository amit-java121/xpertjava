
public class CustomException  extends Exception{

	int errorCode;
	
	public CustomException(String str,int errorCode) {
		super(str);
		this.errorCode=errorCode;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
	
}
