
public class ExceptionTest {
	
	public int devision(int a,int b) {
		int div=0;
		try {
		 //div =a/b;
		 String str=null;
		 str.length();
		 System.out.println("after devision:: ");
		}catch(ArithmeticException e) {
			e.printStackTrace();
			System.out.println("Arithmetic exception ");
		}catch(NullPointerException e) {
			e.printStackTrace();
			System.out.println("nullpointer exception in catch block");
		}
		catch(Exception ae) {
			ae.printStackTrace();
			System.out.println("exception:: ");
		}
		System.out.println("after catch block:: ");
		return div;
	}
	
	public int addition(int aa,int bb) {
		int sum =aa+bb;
		return sum;
		
	}

	public static void main(String[] args) {
		ExceptionTest et = new ExceptionTest();
		int div = et.devision(10, 0);
		System.out.println("division:: "+div);
		 int result = et.addition(5, 5);
		System.out.println("sum:: "+result);
	}
}
