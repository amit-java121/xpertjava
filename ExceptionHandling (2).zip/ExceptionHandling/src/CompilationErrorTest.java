import java.io.IOException;

public class CompilationErrorTest {
	
	public void m1() throws ClassNotFoundException{
		 
		Class.forName("");
		System.out.println(" m1() ");
		
	}
	
	public void m2() throws ClassNotFoundException {
		m1();
	}
	
	
	public static void main(String[] args) {
		CompilationErrorTest ct = new CompilationErrorTest();
		try {
			ct.m2();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
