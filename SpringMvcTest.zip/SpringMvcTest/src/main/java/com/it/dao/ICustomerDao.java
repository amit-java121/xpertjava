package com.it.dao;

import java.util.List;

import com.it.model.Customer;

public interface ICustomerDao {
 public void saveDetails(Customer customer);
 public List<Customer> getCustomerList();
 public Customer getCustomerRecord(int id);
 public void delete(int id);
}
