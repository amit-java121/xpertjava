package com.it.dao;

import com.it.model.Customer;

public interface ICustomerDao {
 public void saveDetails(Customer customer);
}
