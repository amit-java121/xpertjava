package com.it.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveDetails(Customer customer) {

		System.out.println("inside dao class"+customer.toString());
		
		sessionFactory.openSession().saveOrUpdate(customer);
		
	}

	public List<Customer> getCustomerList() {
		
		@SuppressWarnings("unchecked")
		List<Customer> customerList = (List<Customer>)sessionFactory.openSession().createCriteria(Customer.class).list();
		
		return customerList;
	}

	public Customer getCustomerRecord(int id) {

		Customer customerRecord = (Customer)sessionFactory.openSession().get(Customer.class,id);
		
		return customerRecord;
	}

	public void delete(int id) {
		Session session = sessionFactory.openSession();
		Customer customerRecord = (Customer)session.get(Customer.class,id);
		System.out.println("dao delete "+customerRecord.toString());
		
		sessionFactory.openSession().delete(customerRecord);
		session.close();
		
	}

}
