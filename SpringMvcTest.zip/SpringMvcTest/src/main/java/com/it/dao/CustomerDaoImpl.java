package com.it.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.Customer;

@Repository
public class CustomerDaoImpl implements ICustomerDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveDetails(Customer customer) {

		System.out.println("inside dao class"+customer.toString());
		
		sessionFactory.openSession().save(customer);
		
	}

}
