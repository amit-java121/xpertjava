package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.ICustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	
	public void saveCustomerDetails(Customer customer) {
	///logic
		System.out.println("CustomerServiceImpl::::");
		
		customerDao.saveDetails(customer);
		
	}

}
