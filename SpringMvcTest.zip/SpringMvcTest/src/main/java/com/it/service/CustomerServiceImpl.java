package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.ICustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	
	public void saveCustomerDetails(Customer customer) {
	///logic
		System.out.println("CustomerServiceImpl::::");
		
		customerDao.saveDetails(customer);
		
	}

	public List<Customer> getAllCustomer() {
		List<Customer>	listOfCustomer = customerDao.getCustomerList();
		return listOfCustomer;
	}

	@Override
	public Customer updateCustomerRecord(int id) {
		
		return customerDao.getCustomerRecord(id);
	}

	@Override
	public void delete(int id) {
		
		customerDao.delete(id);
	}

}
