package com.it.service;

import java.util.List;

import com.it.model.Customer;

public interface ICustomerService {

	public void saveCustomerDetails(Customer customer);
	public List<Customer> getAllCustomer();
	public Customer updateCustomerRecord(int id);
	public void delete(int id);
}
