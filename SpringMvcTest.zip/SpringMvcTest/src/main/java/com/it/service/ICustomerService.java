package com.it.service;

import com.it.model.Customer;

public interface ICustomerService {

	public void saveCustomerDetails(Customer customer);
}
