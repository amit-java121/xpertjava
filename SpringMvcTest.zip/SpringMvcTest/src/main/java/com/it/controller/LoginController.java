package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.Customer;
import com.it.service.ICustomerService;

@Controller
public class LoginController {
	
	@Autowired
	ICustomerService customerService;
	
	@GetMapping("/")
	public String getLoginPage() {
		
		return "login";
	}
	
	@GetMapping("/customerLogin")
	public void loginDeatils(@RequestParam String customerName,@RequestParam String customerPassword) {
		System.out.println("customer name: "+customerName+" password: "+customerPassword);
	}
	
	@GetMapping("/customer-form")
	public ModelAndView customerPage() {
		ModelAndView model = new ModelAndView("customerForm");
		model.addObject("customer", new Customer());
		return model;
	}
	
	@PostMapping("/save")
	public String saveCustomerDetails(@ModelAttribute Customer customer) {
		System.out.println(customer.getFirstname() + customer.getLastname());
		
		customerService.saveCustomerDetails(customer);
		
		return "redirect:/listCustomer";
	}
	
	@GetMapping("/listCustomer")
	public ModelAndView getCustomerList() {
		List<Customer> listOfCustomer = customerService.getAllCustomer();
		
		ModelAndView model = new ModelAndView("customerList");
		model.addObject("customerList", listOfCustomer);
		
		return model;
	}
	
	@GetMapping("/update/{id}")
	public ModelAndView updateCustomer(@PathVariable("id") int id) {
		
		ModelAndView model = new ModelAndView("customerForm");
		System.out.println("id: "+id);
		
		Customer custRecord = customerService.updateCustomerRecord(id);
		System.out.println(custRecord.toString());
		
		model.addObject("customer", custRecord);
		
		return model;
	}
	
	@PostMapping("/update/save")
	public String updateCustomerDetails(@ModelAttribute Customer customer) {
		System.out.println(customer.getFirstname() + customer.getLastname());
		
		customerService.saveCustomerDetails(customer);
		
		return "redirect:/listCustomer";
	}

	@GetMapping("/delete/{id}")
	public String deleteRecord(@PathVariable("id") int id) {
		System.out.println("delete");
		customerService.delete(id);
		

		return "redirect:/listCustomer";
	}
}
