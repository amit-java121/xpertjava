package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.Customer;
import com.it.service.ICustomerService;

@Controller
public class LoginController {
	
	@Autowired
	ICustomerService customerService;
	
	@GetMapping("/")
	public String getLoginPage() {
		
		return "login";
	}
	
	@GetMapping("/customerLogin")
	public void loginDeatils(@RequestParam String customerName,@RequestParam String customerPassword) {
		System.out.println("customer name: "+customerName+" password: "+customerPassword);
	}
	
	@GetMapping("/customer-form")
	public ModelAndView customerPage() {
		ModelAndView model = new ModelAndView("customerForm");
		model.addObject("customer", new Customer());
		return model;
	}
	
	@PostMapping("/save")
	public void saveCustomerDetails(@ModelAttribute Customer customer) {
		System.out.println(customer.getFirstname() + customer.getLastname());
		
		customerService.saveCustomerDetails(customer);
	}

}
