package service;

import dao.DataBaseImpl;
import dao.User;

public class LoginServiceImpl {

	public void checkUser(String username, String password) {
		
		DataBaseImpl dbi = new DataBaseImpl();
		User usr= dbi.getUserDetails(username);
		System.out.println(usr.getUserEmail());
		System.out.println(usr.getPassword());
		//compare user name and password
		
	}

}
