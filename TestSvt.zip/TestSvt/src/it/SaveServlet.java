package it;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DataBaseImpl;
import dao.User;

/**
 * Servlet implementation class SaveServlet
 */
@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("userName");
		String pass = request.getParameter("password");
		String useremail = request.getParameter("userEmail");
		String mpno = request.getParameter("userMBNumber");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		User user  = new User();
		user.setUserName(username);
		user.setUserEmail(useremail);
		user.setPassword(pass);
		user.setGender(gender);
		user.setCountry(country);
		user.setMobileNo(Long.valueOf(mpno));
		
		DataBaseImpl db = new DataBaseImpl();
		boolean flag = db.saveUserDetails(user);
		if(flag) {
			request.setAttribute("message", "User is successfully saved!");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}else {
			request.setAttribute("message", "User is not successfully saved!");
			RequestDispatcher rd = request.getRequestDispatcher("userForm.jsp");
			rd.forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
