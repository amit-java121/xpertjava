package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DataBaseImpl {
	
	public User getUserDetails(String userEmail) {
		User user = new User();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		  Statement  stmt = conn.createStatement();
		  ResultSet rs = stmt.executeQuery("select * from emp where id=107");
		  
		  while(rs.next()) {
			  user.setUserEmail(rs.getString("userEmail"));
			  user.setPassword(rs.getString("password"));
		  }
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

}
