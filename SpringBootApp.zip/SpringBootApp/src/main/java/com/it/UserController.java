package com.it;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.it.model.User;
import com.it.service.IUserService;

@RestController
public class UserController {
	
	
	@Autowired
	IUserService iUserService;
	
//	@GetMapping("/login")
//	public String loginUser(@RequestParam("userName") String userName,@RequestParam("userPass") String userPass) {
//		System.out.println("login method executed "+userName+" pass "+userPass);
//		
//		return "You are in login method!!";
//	}
	
	@GetMapping("/login/{userName}/{userPass}")
	public String loginUser(@PathVariable String userName,@PathVariable String userPass) {
		System.out.println("login method executed "+userName+" pass "+userPass);
		boolean isUserChecked= iUserService.checkUser(userName,userPass);
		if(isUserChecked) {
			return "You are in login method!!";
		}
		return "You are not authorized user!!!";
	}
	
	@PostMapping("/save")
	public String saveUserDetails(@RequestBody User user) {
		System.out.println("we are in save method:: ");
		boolean flag = iUserService.saveUserDetails(user);
		if(flag) {
			return "User details saved successfully!!";
		}
		return "User details are not saved successfully!!";
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable int id) {
		System.out.println("delete method executed!!"+id);
		return "User deleted successully!!";
	}
	
	@GetMapping("/getUserDetails")
	public List<User> userDeatils() {
		
		List<User> userList = iUserService.getUserDetails();
		return userList;
	}

}
