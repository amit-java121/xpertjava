package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserDao;
import com.it.model.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	IUserDao iUserDao;
	
	@Override
	public boolean checkUser(String userName,String userPass) {
		
		User user = iUserDao.getUserDetails(userName);
		
		if(user != null && user.getUserName() != null && user.getUserName().equalsIgnoreCase(userName) 
				&& user.getUserPass() !=null && user.getUserPass().equalsIgnoreCase(userPass)) {
			return true;
			
		}
		return false;
	}

	@Override
	public boolean saveUserDetails(User user) {
		// TODO Auto-generated method stub
		return iUserDao.saveUser(user);
	}

	@Override
	public List<User> getUserDetails() {
		
		return iUserDao.getUserData();
	}

}
