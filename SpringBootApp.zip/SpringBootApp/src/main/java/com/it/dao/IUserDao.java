package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface IUserDao {
	
	public User getUserDetails(String userName);

	public boolean saveUser(User user);

	public List<User> getUserData();

}
