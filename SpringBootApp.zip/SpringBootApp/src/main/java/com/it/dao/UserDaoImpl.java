package com.it.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public class UserDaoImpl implements IUserDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserDetails(String userName) {
		User user = new User();
		Session session = sessionFactory.openSession().getSession();

		Query query = session.createQuery("from User where userName=:user_name");
		query.setParameter("user_name", userName);
		List userList = query.getResultList();
		if(userList!= null && userList.size() > 0) {
		  user = (User)userList.get(0);
		}		
		return user;
		
	}

	@Override
	public boolean saveUser(User user) {
		boolean flag = true;
		Session session = sessionFactory.openSession().getSession();
		try {
			session.saveOrUpdate(user);
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	@Override
	public List<User> getUserData() {

		Session session = sessionFactory.openSession().getSession();
		Criteria criteria =session.createCriteria(User.class);
		
		return (List<User>)criteria.list();
	}

}
