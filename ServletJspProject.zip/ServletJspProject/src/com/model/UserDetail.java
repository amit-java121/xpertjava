package com.model;

import java.io.Serializable;

public class UserDetail implements Serializable{
	
	private static final long serialVersionUID = 2547352618468754453L;
	
	private int userId;
	private String userName;
	private String password;
	private long moblieNumber;
	private String userEmail;
	private String gender;
	private String country;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getMoblieNumber() {
		return moblieNumber;
	}
	public void setMoblieNumber(long moblieNumber) {
		this.moblieNumber = moblieNumber;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "UserDetail [userId=" + userId + ", userName=" + userName + ", password=" + password + ", moblieNumber="
				+ moblieNumber + ", userEmail=" + userEmail + ", gender=" + gender + ", country=" + country + "]";
	}

	
	

}
