package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.UserDetail;

public class DataBaseConnection {

	public UserDetail checkUserDetails(String userEmail, String password) {
		Connection conn = null;
		boolean flag = false;
		UserDetail userDetail = new UserDetail();
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			 ResultSet rs = stmt.executeQuery("select user_email,password from user_details where user_email='"+userEmail+"'");
			
			while (rs.next()) {
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				
			}
			 
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return userDetail;
	}
	
	public boolean saveDetail(UserDetail userDetail) {
		Connection conn = null;
		boolean flag = false;
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			//Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			PreparedStatement ps = conn.prepareStatement("insert into user_details (user_name,password,user_email,user_mb_number,gender,country) values(?,?,?,?,?,?)");
			ps.setString(1, userDetail.getUserName());
			ps.setString(2, userDetail.getPassword());
			ps.setString(3, userDetail.getUserEmail());
			ps.setLong(4, userDetail.getMoblieNumber());
			ps.setString(5, userDetail.getGender());
			ps.setString(6, userDetail.getCountry());
			// int i = stmt.executeUpdate("insert into user (user_name, user_password) values ('"+userName+"','"+password+"')");
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}
	
	public List<UserDetail> fetchDetail() {
		Connection conn = null;
		List<UserDetail> listOfUser = new ArrayList<>();
		
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			//Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			PreparedStatement ps = conn.prepareStatement("select * from user_details");
			// int i = stmt.executeUpdate("insert into user (user_name, user_password) values ('"+userName+"','"+password+"')");
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				UserDetail userDetail = new UserDetail();
				userDetail.setUserId(rs.getInt("userId"));
				userDetail.setUserName(rs.getString("user_name"));
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				userDetail.setMoblieNumber(rs.getLong("user_mb_number"));
				userDetail.setGender(rs.getString("gender"));
				userDetail.setCountry(rs.getString("country"));
				
				listOfUser.add(userDetail);
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return listOfUser;
	}

	
	public UserDetail fetchUpdateDetails(int userId) {
		Connection conn = null;
		UserDetail userDetail = new UserDetail();
		
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			//Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			PreparedStatement ps = conn.prepareStatement("select * from user_details where userId=?");
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				userDetail.setUserId(rs.getInt("userId"));
				userDetail.setUserName(rs.getString("user_name"));
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				userDetail.setMoblieNumber(rs.getLong("user_mb_number"));
				userDetail.setGender(rs.getString("gender"));
				userDetail.setCountry(rs.getString("country"));
			
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return userDetail;
	}

	
	
	public boolean saveUpdateUserDeatils(UserDetail userDetail) {
		Connection conn = null;
		boolean flag = false;
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			//Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			PreparedStatement ps = conn.prepareStatement("update user_details set 'user_name','user_email','user_mb_number','gender',country' values ?,?,?,?,? where userId='"+userDetail.getUserId()+"'");
			ps.setString(1, userDetail.getUserName());
			ps.setString(2, userDetail.getUserEmail());
			ps.setLong(3, userDetail.getMoblieNumber());
			ps.setString(4, userDetail.getGender());
			ps.setString(5, userDetail.getCountry());
			// int i = stmt.executeUpdate("insert into user (user_name, user_password) values ('"+userName+"','"+password+"')");
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}

}
