package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.UserDetail;

public class DataBaseConnection {

	private Connection getConnection() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
		return conn;
	}
	public UserDetail checkUserDetails(String userEmail, String password) {
		Connection conn = null;
		UserDetail userDetail = new UserDetail();
		try {
			conn = getConnection();
			Statement stmt = conn.createStatement();
			 ResultSet rs = stmt.executeQuery("select user_email,password from user_details where user_email='"+userEmail+"'");
			
			while (rs.next()) {
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				
			}
			 
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return userDetail;
	}
	
	public boolean saveDetail(UserDetail userDetail) {
		Connection conn = null;
		boolean flag = false;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("insert into user_details (user_name,password,user_email,user_mb_number,gender,country) values(?,?,?,?,?,?)");
			ps.setString(1, userDetail.getUserName());
			ps.setString(2, userDetail.getPassword());
			ps.setString(3, userDetail.getUserEmail());
			ps.setLong(4, userDetail.getMoblieNumber());
			ps.setString(5, userDetail.getGender());
			ps.setString(6, userDetail.getCountry());
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}
	
	public List<UserDetail> fetchDetail() {
		Connection conn = null;
		List<UserDetail> listOfUser = new ArrayList<>();
		
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("select * from user_details");
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				UserDetail userDetail = new UserDetail();
				userDetail.setUserId(rs.getInt("userId"));
				userDetail.setUserName(rs.getString("user_name"));
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				userDetail.setMoblieNumber(rs.getLong("user_mb_number"));
				userDetail.setGender(rs.getString("gender"));
				userDetail.setCountry(rs.getString("country"));
				
				listOfUser.add(userDetail);
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return listOfUser;
	}

	
	public UserDetail fetchUpdateDetails(int userId) {
		Connection conn = null;
		UserDetail userDetail = new UserDetail();
		
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("select * from user_details where userId=?");
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				userDetail.setUserId(rs.getInt("userId"));
				userDetail.setUserName(rs.getString("user_name"));
				userDetail.setPassword(rs.getString("password"));
				userDetail.setUserEmail(rs.getString("user_email"));
				userDetail.setMoblieNumber(rs.getLong("user_mb_number"));
				userDetail.setGender(rs.getString("gender"));
				userDetail.setCountry(rs.getString("country"));
			
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return userDetail;
	}

	
	
	public boolean saveUpdateUserDeatils(UserDetail userDetail) {
		Connection conn = null;
		boolean flag = false;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("update user_details set user_name=?,user_email=?,user_mb_number=?,gender=?,country=? where userId=?");
			ps.setString(1, userDetail.getUserName());
			ps.setString(2, userDetail.getUserEmail());
			ps.setLong(3, userDetail.getMoblieNumber());
			ps.setString(4, userDetail.getGender());
			ps.setString(5, userDetail.getCountry());
			ps.setInt(6, userDetail.getUserId());
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}

	public boolean deleteRecord(int userId) {
		
		Connection conn = null;
		boolean flag = false;
		try {
			conn = getConnection();
			PreparedStatement ps = conn.prepareStatement("delete from user_details where userId=?");
			ps.setInt(1, userId);
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
		
	}

}
