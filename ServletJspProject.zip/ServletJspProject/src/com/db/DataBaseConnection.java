package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.model.UserDetail;

public class DataBaseConnection {

	public boolean saveUserDetails(String userName, String password) {
		Connection conn = null;
		boolean flag = false;
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
			System.out.println("step 3 ");
			Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			 int i = stmt.executeUpdate("insert into user (user_name, user_password) values ('"+userName+"','"+password+"')");
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}
	
	public boolean saveDetail(UserDetail userDetail) {
		Connection conn = null;
		boolean flag = false;
		try {
			System.out.println("step 1 ");
			Class.forName("com.mysql.cj.jdbc.Driver");

			System.out.println("step 2 ");
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/user","root","root");
			System.out.println("step 3 ");
			//Statement stmt = conn.createStatement();
			System.out.println("step 4 ");
			PreparedStatement ps = conn.prepareStatement("insert into user_details (user_name,password,user_email,user_mb_number,gender,country) values(?,?,?,?,?,?)");
			ps.setString(1, userDetail.getUserName());
			ps.setString(2, userDetail.getPassword());
			ps.setString(3, userDetail.getUserEmail());
			ps.setLong(4, userDetail.getMoblieNumber());
			ps.setString(5, userDetail.getGender());
			ps.setString(6, userDetail.getCountry());
			// int i = stmt.executeUpdate("insert into user (user_name, user_password) values ('"+userName+"','"+password+"')");
			
			int i= ps.executeUpdate();
			
			if(i > 0) {
				flag = true;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		return flag;
	}
	
}
