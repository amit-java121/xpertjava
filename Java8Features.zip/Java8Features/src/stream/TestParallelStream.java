package stream;

import java.util.Arrays;
import java.util.List;

public class TestParallelStream {
	
	public static void main(String[] args) {
		
	//	List<Integer> listOfNumbers = Arrays.asList(1, 2, 3, 4);
	//	listOfNumbers.stream().forEach(number -> System.out.println(number + " " + Thread.currentThread().getName()));
		
		
		List<Integer> listOf = Arrays.asList(1, 2, 3, 4);
		listOf.parallelStream().forEach(number -> System.out.println(number + " " + Thread.currentThread().getName()));
		
		
	}

}
