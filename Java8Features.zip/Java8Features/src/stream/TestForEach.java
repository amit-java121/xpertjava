package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class TestForEach {

	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		list.add("mumbai");
		list.add("pune");
		list.add("nagpur");
		list.add("solapur");
		list.add("jalgaon");
		
		
//		for(String str:list) {
//			System.out.println(str);
//		}
//		
	//	list.stream().forEach(System.out::println);
		
		//min funtion
		
		List<Integer> intList = Arrays.asList(2, 4, 1, 3, 7, 5, 9, 6, 8);
		 
        Optional<Integer> minNumber = intList.stream().min((i, j) -> i.compareTo(j));
        System.out.println(minNumber.get());
        
    	//max funtion
        Optional<Integer> maxNumber = intList.stream().max((i, j) -> i.compareTo(j));
        System.out.println(maxNumber.get());
        
        //count
        long count = list.stream().count();
        System.out.println(count);
        
        //anymatch
        boolean flag = list.stream().anyMatch(l ->l.equalsIgnoreCase("pune"));
		System.out.println(flag);
	}
}
