package stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class TestSorted {
	
	public static void main(String[] args) 
    {
		List<String> list = new ArrayList<>();
		list.add("mumbai");
		list.add("pune");
		list.add("nagpur");
		list.add("solapur");
		list.add("jalgaon");
 
       // List<String> sortedList = list.stream().sorted().collect(Collectors.toList());
        //System.out.println(sortedList);
        
        List<String> reverseList = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println(reverseList);
     
        
    }

}
