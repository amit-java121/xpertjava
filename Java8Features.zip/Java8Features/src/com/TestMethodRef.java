package com;

public class TestMethodRef {
	
	public static String  show(String str) {
		System.out.println("we are in show");
		return str;
	}
	
	public static void main(String[] args) {
		
		IMethodRefernceInterface mr = TestMethodRef::show;
		
		String msg = mr.print("hi:::");
		
		System.out.println(msg);
		
	}

}
