package com;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TestOptional {
	
	public static void main(String[] args) {
		
		Employee e = new Employee();
		e.setEmpid(100);
		e.setEmpName("amit");
		
		Employee e2 = new Employee();
		e2.setEmpid(102);
		e2.setEmpName("rohan");
		
		Employee e3 = new Employee();
		e3.setEmpid(103);
		//e3.setEmpName("rohan");
		
		
		List<Employee> listOfEmp = new ArrayList<Employee>();
		listOfEmp.add(e);
		listOfEmp.add(e2);
		listOfEmp.add(e3);
		
		List<Employee> newArraYList = new ArrayList<Employee>();
		
		for(int i=0;i<listOfEmp.size();i++) {
			
			Employee emp = listOfEmp.get(i);
			
			Optional<String> op = Optional.ofNullable(emp.getEmpName());
			
			if(op.isPresent() && emp.getEmpName().equalsIgnoreCase("rohan")) {
				newArraYList.add(emp);
			}
			
		}
		System.out.println(newArraYList.toString());
		
	}

}
