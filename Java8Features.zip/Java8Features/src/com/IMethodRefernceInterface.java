package com;

public interface IMethodRefernceInterface {
	
	public String print(String str);

}
