package com;

public class Test {
	
	public static void main(String[] args) {
		
		IFunctionalInterface fi = (a,b) -> {
			int c=a+b;
			return c;
		};
		System.out.println("");	
	
		int sum = fi.add(5, 5);
		System.out.println(sum);
		
		
		new Thread(
				()-> {
					for(int a=0;a<5;a++) {
						System.out.println("runnable thread");
					}
					
				}
				).start();
		
		
	}

}
