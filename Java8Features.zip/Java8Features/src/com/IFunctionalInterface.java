package com;

@FunctionalInterface
public interface IFunctionalInterface {
	
	public int add(int a,int b);
	
	default void m1() {
		//logic
		
		System.out.println("default:::");
	}

	public static void m2() {
		System.out.println("static ::");
	}
}
