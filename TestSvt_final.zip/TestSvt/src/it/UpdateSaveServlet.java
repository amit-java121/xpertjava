package it;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DataBaseImpl;
import dao.User;

/**
 * Servlet implementation class UpdateSaveServlet
 */
@WebServlet("/saveUpdate")
public class UpdateSaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateSaveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String userId = request.getParameter("id");
		String username = request.getParameter("userName");
		String pass = request.getParameter("password");
		String useremail = request.getParameter("userEmail");
		String mpno = request.getParameter("userMBNumber");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		User user  = new User();
		user.setId(Integer.valueOf(userId));
		user.setUserName(username);
		user.setUserEmail(useremail);
		user.setPassword(pass);
		user.setGender(gender);
		user.setCountry(country);
		user.setMobileNo(Long.valueOf(mpno));
		
		DataBaseImpl db = new DataBaseImpl();
		boolean flag = db.updateUserDetails(user);
		
		if(flag) {
			DataBaseImpl db1 = new DataBaseImpl();
			ArrayList<User> userList = db1.getUserDeatils();
			request.setAttribute("userList", userList);
			request.getRequestDispatcher("success.jsp").forward(request, response);
		}else {
			request.setAttribute("updateMsg", "Record is not updated!");
			request.getRequestDispatcher("update.jsp").forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
