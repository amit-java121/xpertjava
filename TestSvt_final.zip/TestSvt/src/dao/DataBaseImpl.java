package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class DataBaseImpl {
	
	public User getUserDetails(String userEmail) {
		User user = new User();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		  Statement  stmt = conn.createStatement();
		  ResultSet rs = stmt.executeQuery("select * from emp where userEmail='"+userEmail+"'");
		  
		  while(rs.next()) {
			  user.setUserEmail(rs.getString("userEmail"));
			  user.setPassword(rs.getString("password"));
		  }
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
	}

	public boolean saveUserDetails(User user) {
		boolean flag=false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");

		PreparedStatement pstmt = conn.prepareStatement("insert into emp (name,userEmail,password,gender,country,mobileNo) values(?,?,?,?,?,?)");
		
		pstmt.setString(1, user.getUserName());
		pstmt.setString(2, user.getUserEmail());
		pstmt.setString(3, user.getPassword());
		pstmt.setString(4, user.getGender());
		pstmt.setString(5, user.getCountry());
		pstmt.setLong(6, user.getMobileNo());
		
		int i = pstmt.executeUpdate();
		if(i>0) {
			flag=true;
		}else {
			flag=false;
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}
	
	public ArrayList<User> getUserDeatils() {
		ArrayList<User> userList = new ArrayList<>();
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		 PreparedStatement ptstm = conn.prepareStatement("select * from emp");
		 ResultSet rs = ptstm.executeQuery();
		 while(rs.next()) {
			 User user = new User();
			 user.setUserName(rs.getString("name"));
			 user.setUserEmail(rs.getString("userEmail"));
			 user.setGender(rs.getString("gender"));
			 user.setPassword(rs.getString("password"));
			 user.setCountry(rs.getString("country"));
			 user.setMobileNo(rs.getLong("mobileNo"));
			 user.setId(rs.getInt("id"));
			 
			 userList.add(user);
		 }
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userList;
	}

	public User fetchUserById(Integer userId) {
	
		User user = new User();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		  Statement  stmt = conn.createStatement();
		  ResultSet rs = stmt.executeQuery("select * from emp where id="+userId+"");
		  
		  while(rs.next()) {
			     user.setUserName(rs.getString("name"));
				 user.setUserEmail(rs.getString("userEmail"));
				 user.setGender(rs.getString("gender"));
				 user.setPassword(rs.getString("password"));
				 user.setCountry(rs.getString("country"));
				 user.setMobileNo(rs.getLong("mobileNo"));
				 user.setId(rs.getInt("id"));
		  }
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return user;
		
	}

	public boolean updateUserDetails(User user) {
		boolean flag=false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		
		 PreparedStatement ptst = conn.prepareStatement("update emp set name=?,userEmail=?,gender=?,password=?,country=?,mobileNo=? where id=?");
		 ptst.setString(1, user.getUserName());
		 ptst.setString(2, user.getUserEmail());
		 ptst.setString(3, user.getGender());
		 ptst.setString(4, user.getPassword());
		 ptst.setString(5, user.getCountry());
		 ptst.setLong(6, user.getMobileNo());
		 ptst.setInt(7, user.getId());
		 
		 int i= ptst.executeUpdate();
		 if(i>0) {
			  flag = true;
		 }else {
			 flag = false;
		 }
		 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	public boolean delete(int userID) {
		boolean flag=false;
		try {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		
		PreparedStatement ptst = conn.prepareStatement("delete from emp where id=?");
		ptst.setInt(1, userID);
		
		int i = ptst.executeUpdate();
		if(i>0) {
			flag=true;
		}else {
			flag=false;
		}
		
		}catch(Exception e) {
			
		}
		return flag;
	}

}
