package service;

import dao.DataBaseImpl;
import dao.User;

public class LoginServiceImpl {

	public boolean checkUser(User user) {
		boolean flag=false;
		
		DataBaseImpl dbi = new DataBaseImpl();
		User usr= dbi.getUserDetails(user.getUserEmail());
		
		if(user.getUserEmail().equals(usr.getUserEmail()) && user.getPassword().equals(usr.getPassword())) {
			flag =true;
		}else {
			flag =false;
		}
		
		
		System.out.println(usr.getUserEmail());
		System.out.println(usr.getPassword());
		//compare user name and password
		
		return flag;
	}

}
