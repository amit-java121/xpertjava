package com;

import java.io.Serializable;

public class PaymentEmp implements Serializable{
	
	private static final long serialVersionUID = -5364180757564910470L;
	
	int id;
	String name;
	static String address;
	transient int phoneNo;
	
	public PaymentEmp(int id, String name, int phoneNo,String address) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static String getAddress() {
		return address;
	}
	public static void setAddress(String address) {
		PaymentEmp.address = address;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

}
