package com;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class PaymentTest {
	
	public static void main(String[] args) {
		PaymentEmp payment = new PaymentEmp(1000, "xpert",1234598, "Pune");
		try {
		FileOutputStream fio = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fio);
		oos.writeObject(payment);
		oos.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
