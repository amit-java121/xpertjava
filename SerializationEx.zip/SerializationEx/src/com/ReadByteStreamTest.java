package com;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class ReadByteStreamTest {
	
	public static void main(String[] args) {
		try {
			
			FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			PaymentEmp obj = (PaymentEmp)ois.readObject();
			
			System.out.println("id: "+obj.getId()+" name: "+obj.getName()+" address:"+obj.getAddress()+" phone: "+obj.getPhoneNo());
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
