package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EmployeeTest {
	
	public static void main(String[] args) {
		//PaymentEmp payment = new PaymentEmp(1000, "xpert",1234598, "Pune");
//		Employee emp = new Employee(1000, "xpert",1234598, "Pune");
//		emp.setEmpId(101);
//		emp.setEmpName("Emp name");
		try {
//		FileOutputStream fio = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
//		ObjectOutputStream oos = new ObjectOutputStream(fio);
//		oos.writeObject(emp);
//		oos.close();
		
		
		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Employee obj = (Employee)ois.readObject();
		
		System.out.println("id: "+obj.getId()+" name: "+obj.getName()+" address:"+obj.getAddress()+" phone: "+obj.getPhoneNo());
		System.out.println("emp id: "+obj.getEmpId()+" emp name: "+obj.getEmpName());
		ois.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
