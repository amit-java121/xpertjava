package com;

public class Employee extends PaymentEmp{

	private static final long serialVersionUID = -7281030329323638792L;

	int empId;
	String empName;

	Employee(int id, String name, int phoneNo, String address) {
		super(id, name, phoneNo, address);
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}
	
	

}
