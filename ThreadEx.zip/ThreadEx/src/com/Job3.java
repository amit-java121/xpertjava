package com;

public class Job3 implements Runnable{

	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println(i);
		}
		
	}
	
	
	
	public static void main(String[] args) {
		
		Job3 job3 = new Job3();
		Thread th = new Thread(job3);
		th.start();
		
	}

}
