package com;

public class Job extends Thread {

	@Override
	public void run() {
		System.out.println("Job thread: "+Thread.currentThread().getName());
		for(int i=10;i<20;i++) {
			System.out.println("i:: "+i);
		}
	}
}
