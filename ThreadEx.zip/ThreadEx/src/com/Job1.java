package com;

public class Job1 extends Thread{

	@Override
	public void run() {
		System.out.println("thread name: "+Thread.currentThread().getId());
		for(int i=20;i<30;i++) {
			System.out.println("job1 "+i);
			try {
				sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
