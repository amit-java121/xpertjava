package com;

public class TriggerTask {
	
	public static void main(String[] args) {
		
//		for(int i=0;i<10;i++) {
//			System.out.println("i::"+i);
//		}
		System.out.println("main thread: "+Thread.currentThread().getName());
		Job job = new Job();
		job.setName("HDFC");
		job.start();
		System.out.println("thread: "+Thread.currentThread().getName());
		//job.start();
		Job job1 = new Job();
		job1.setName("ICICI");
		job1.start();
		System.out.println("main thread: "+Thread.currentThread().getName());
//		for(int i=20;i<30;i++) {
//			System.out.println("i::"+i);
//		}
		
	}

}
