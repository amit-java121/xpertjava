package com;

public class Transaction extends Thread{
	
	static int balance=1000;
	
	@Override
	public void run() {
	
		for(int i=0;i<10;i++) {
		  withdraw(150);
		}
	}

    private static synchronized void withdraw(int amt) {

		System.out.println("trying to withdraw "+Thread.currentThread().getName());
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(balance>200) {
			balance = balance-amt;
			System.out.println("remaining balance: "+balance);
		}else {
			System.out.println("in sufficient fund::");
		}
	}

}
