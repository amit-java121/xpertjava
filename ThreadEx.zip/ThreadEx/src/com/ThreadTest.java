package com;

public class ThreadTest {
	public static void main(String[] args) {
		Transaction tr = new Transaction();
		tr.setName("HDFC");
		 tr.start();
		 
		 Transaction tr1 = new Transaction();
			tr1.setName("ICICI");
		 tr1.start();
	}

}
