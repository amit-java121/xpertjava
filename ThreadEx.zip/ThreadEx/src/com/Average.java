package com;

public class Average extends Thread{

	@Override
	public void run() {
	
		System.out.println("Average:: "+(Sum.sum/Sum.count));
		
	}
}
