package com;

public class Sum extends Thread{
	static int sum=0;
	static int count=0;
	
	@Override
	public void run() {
	for(int i=0;i<1000000;i++) {
		sum=sum+i;
		count++;
	}
	System.out.println("sum:: "+sum);
		
	}
}
