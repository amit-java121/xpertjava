package com;

public class TriggerSumAvg {
	
	public static void main(String[] args) throws InterruptedException {
		Sum s = new Sum();
		s.start();
		s.join();
		
		Average av = new Average();
		 av.start();
	}

}
