package com;

public class JobRunnableTrigger {
	
	public static void main(String[] args) {
		JobRunnable jb = new JobRunnable();
		
		Thread th = new Thread(jb);
		th.start();
	}

}
