package set;

import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {
		TreeMap<String, String> tree = new TreeMap<>();
		tree.put("A", "abc");
		tree.put("D", "abc1");
		tree.put("B", null);
		
		
		NavigableMap<String, String> maptree = tree.descendingMap();
		for (Entry<String, String> tr: maptree.entrySet()) {
		
			System.out.println("key:: "+tr.getKey() +" value: "+tr.getValue());
		}
	}
	

}
