package set;

import java.util.TreeSet;

public class TestTreeSet {
	
	public static void main(String[] args) {
		TreeSet<String> tree = new TreeSet<String>();
		tree.add("A");
		tree.add("D");
		tree.add("E");
		tree.add("B");
		//tree.add(null);
		
		
		for (String string : tree) {
			System.out.println(string);
		}
		
		System.out.println(tree.descendingSet());
	}

}
