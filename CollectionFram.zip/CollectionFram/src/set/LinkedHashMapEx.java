package set;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LinkedHashMapEx {
	
	public static void main(String[] args) {
		 LinkedHashMap<String, String> linkedMap = new LinkedHashMap<String, String>();
		 linkedMap.put("A", "xpert");
		 linkedMap.put("B", "xpert1");
		 linkedMap.put("D", "xpert2");
		 linkedMap.put("E", "xpert3");
		 
		 System.out.println("value:: "+linkedMap.get("D"));
		 System.out.println("value:: "+linkedMap.values());
		 
		 for ( Entry<String, String> map : linkedMap.entrySet()) {
			System.out.println(map.getKey()+" value: "+map.getValue());
		}
	}
	 		

}
