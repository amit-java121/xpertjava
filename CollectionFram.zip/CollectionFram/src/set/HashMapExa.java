package set;

import java.util.HashMap;
import java.util.Map.Entry;

public class HashMapExa {
	
	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(100, "nitesh");
		map.put(101, "nitesh1");
		map.put(102, null);
		map.put(null, null);
		
		System.out.println(map.size());
		
		for (Entry<Integer, String> m : map.entrySet()) {
			System.out.println("Key: "+m.getKey()+" value: "+m.getValue());
		}
		
	}

}
