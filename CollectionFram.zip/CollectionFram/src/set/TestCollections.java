package set;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestCollections {
	
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		list.add("abc");
		list.add("abc2");
		list.add("abc3");
		
		List<String> unModList = Collections.unmodifiableList(list);
		System.out.println(unModList.toString());
		unModList.add("xyz");
		System.out.println(unModList);
	}

}
