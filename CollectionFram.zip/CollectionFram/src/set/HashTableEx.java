package set;

import java.util.Hashtable;
import java.util.Map.Entry;

public class HashTableEx {

	public static void main(String[] args) {
		Hashtable<String, String> table = new Hashtable<>();
		table.put("A", "xpert");
		table.put("b", "xpert1");
		table.put("c", "xpert2");
		table.put("D", null);
		
		
		for ( Entry<String, String> ta : table.entrySet()) {
			System.out.println("key:: "+ta.getKey()+"value:: "+ta.getValue());
		}
	}
}
