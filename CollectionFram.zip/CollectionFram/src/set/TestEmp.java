package set;

import java.util.HashMap;
import java.util.Map.Entry;

public class TestEmp {
	
	public static void main(String[] args) {
		Employee emp = new Employee(100, "xpert", "Pune");
		Employee emp1 = new Employee(101, "xpert1", "Mumbai");
		Employee emp2 = new Employee(102, "xpert2", "Nagpur");
		Employee emp3 = new Employee(103, "xpert3", "Pune");
		
		HashMap<Integer, Employee> empMap = new HashMap<Integer, Employee>();
		empMap.put(emp.getEmpId(), emp);
		empMap.put(emp1.getEmpId(), emp1);
		empMap.put(emp2.getEmpId(), emp2);
		empMap.put(emp3.getEmpId(), emp3);
		
		for ( Entry<Integer, Employee> em : empMap.entrySet()) {
			
			System.out.println("emp id : "+em.getKey() +" value:: "+em.getValue());
		}
		
	}

}
