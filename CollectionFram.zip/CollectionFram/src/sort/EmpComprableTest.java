package sort;

import java.util.ArrayList;
import java.util.Collections;

public class EmpComprableTest {
	
	public static void main(String[] args) {
		Employee emp = new Employee(100, "nitesh", "Pune");
		Employee emp1 = new Employee(102, "Vishal", "Pune");
		Employee emp2 = new Employee(101, "abc", "Mumbai");
		Employee emp3 = new Employee(104, "xyz", "Nagpur");
		
		ArrayList<Employee> empList = new ArrayList<Employee>();
			empList.add(emp);
			empList.add(emp1);
			empList.add(emp2);
			empList.add(emp3);
			
		Collections.sort(empList);
		
		for (Employee employee : empList) {
			System.out.println(employee.toString());
		}
		
		
	}
}
