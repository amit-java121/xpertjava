package sort;

public class Employee implements Comparable<Employee>{
	int empId;
	String empName;
	String empAddress;
	
	
	public Employee(int empId, String empName, String empAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empAddress = empAddress;
	}
	
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empAddress=" + empAddress + "]";
	}


	@Override
	public int compareTo(Employee obj) {

		if(obj.empId == empId) {
			return 0;
		}else if(empId > obj.empId) {
			return 1;
		}else {
			return -1;
		}
	}

}
