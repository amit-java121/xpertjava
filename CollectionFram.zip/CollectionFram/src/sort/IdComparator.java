package sort;

import java.util.Comparator;

public class IdComparator implements Comparator<Employee2>{

	@Override
	public int compare(Employee2 o1, Employee2 o2) {
		if(o1.empId == o2.empId) {
			return 0;
		}else if(o1.empId > o2.empId) {
			return 1;
		}else if(o1.empId < o2.empId) {
			return -1;
		}
		return 0;
	}

}
