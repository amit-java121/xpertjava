package sort;

import java.util.ArrayList;
import java.util.Collections;

public class EmpCompratorTest {

	
	public static void main(String[] args) {
		Employee2 emp = new Employee2(100, "nitesh", "Pune");
		Employee2 emp1 = new Employee2(102, "vishal", "Pune");
		Employee2 emp2 = new Employee2(101, "abc", "Mumbai");
		Employee2 emp3 = new Employee2(104, "xyz", "Nagpur");
		
		ArrayList<Employee2> empList = new ArrayList<Employee2>();
			empList.add(emp);
			empList.add(emp1);
			empList.add(emp2);
			empList.add(emp3);
			
		Collections.sort(empList, new NameComparator());
		
		
		for (Employee2 employee : empList) {
			System.out.println(employee.toString());
		}
		System.out.println("id sorting::::::::::::");
		Collections.sort(empList, new IdComparator());
		
		for (Employee2 employee : empList) {
			System.out.println(employee.toString());
		}
	}
	

}
