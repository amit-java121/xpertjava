package sort;

import java.util.Comparator;

public class NameComparator implements Comparator<Employee2>{

	@Override
	public int compare(Employee2 obj1, Employee2 obj) {
		
		return obj1.empName.compareTo(obj.empName);
	}

}
