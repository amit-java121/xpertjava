package xpert;

import java.util.Iterator;
import java.util.List;

public class EmployeeTest {
	
		public static void main(String[] args) {
		ArrayListTest at = new ArrayListTest();
		List empList = at.test();
			
		Employee emp = new Employee(105,"abc","pune");
		empList.add(1,emp);
		System.out.println("new size: "+empList.size());
		
		System.out.println("removed:: "+empList.remove(1));
		
		System.out.println("new size: "+empList.size());
		//empList.remove(1);
		Iterator itr = empList.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		}

}
