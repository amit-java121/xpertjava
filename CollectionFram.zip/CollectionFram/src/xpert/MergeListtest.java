package xpert;

import java.util.ArrayList;
import java.util.Iterator;

public class MergeListtest {
	
	public static void main(String[] args) {
		ArrayList list = new ArrayList<>();
		Employee emp = new Employee(100, "vishal", "pune");
		Employee emp1 = new Employee(101, "vishal1", "mumbai");
		Employee emp2 = new Employee(102, "vishal2", "nagpur");
		Employee emp3 = new Employee(103, "vishal3", "Thane");
		Employee emp4 = new Employee(104, "vishal4", "pune");
		
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		System.out.println(list.size());
		
		Employee emp5 = new Employee(100, "vishal", "pune");
		Employee emp6 = new Employee(100, "vishal", "pune");
		ArrayList Secondlist = new ArrayList<>();
		Secondlist.add(emp5);
		Secondlist.add(emp5);
		
		System.out.println(Secondlist.size());
		
		list.addAll(0,Secondlist);
		System.out.println(list.size());
		
		Iterator itr = list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
