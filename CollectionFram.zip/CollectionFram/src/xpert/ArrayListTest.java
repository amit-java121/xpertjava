package xpert;

import java.util.ArrayList;
import java.util.List;

import sun.applet.Main;

public class ArrayListTest {
	
	public List test() {
		
		ArrayList list = new ArrayList();
		
		Employee emp = new Employee(100, "vishal", "pune");
		Employee emp1 = new Employee(101, "vishal1", "mumbai");
		Employee emp2 = new Employee(102, "vishal2", "nagpur");
		Employee emp3 = new Employee(103, "vishal3", "Thane");
		Employee emp4 = new Employee(104, "vishal4", "pune");
		
		list.add(emp);
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		
		System.out.println("size:: "+list.size());
		
//			for(int i=0;i<list.size();i++) {
//				System.out.println(list.get(i));
////				Employee em = (Employee)list.get(i);
////				System.out.println(em.getEmpName());
////				System.out.println(em.getEmpId());
////				System.out.println(em.getEmpAddress());
//			}
		return list;
	}
	
	public static void main(String[] args) {
		ArrayListTest alt = new ArrayListTest();
		alt.test();
	}

}
