
public class FinallyTest {
	public static void main(String[] args) {
//		try {
//			int a =10/2;
//			//System.exit(0);
//		}catch(Exception e) {
//			e.printStackTrace();
//			System.out.println("catch block executed:: ");
//		}finally {
//			System.out.println("finally block executed:: ");
//		}
//		System.out.println("after finally:: ");
		
		try {
			int a =10/2;
			//System.exit(0);
		}finally {
			System.out.println("finally block executed:: ");
		}
		System.out.println("after finally:: ");
	}
	}
	
