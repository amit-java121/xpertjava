package com;

public class StringTest {
	
	
	
	public static void main(String[] args) {
		String str ="hello";
		String str1 ="Hello";
		String str2 = new String("hello");
		String str3 = new String("helLLoo");
		
		
		
//		System.out.println(str.charAt(2));
//		System.out.println(str.equalsIgnoreCase(str1));
//		System.out.println(str.equals(str1));
//		System.out.println(str.indexOf('o'));
//		System.out.println(str.length());
//		System.out.println(str.substring(2, 4));
//		System.out.println(str.toLowerCase());
//		System.out.println(str.toUpperCase());
		
		String str5 ="my name is amit";
		String[] strArr = str5.split(" ");
		for(int i=0; i<strArr.length;i++) {
			System.out.println(strArr[strArr.length - i-1]);
		}
		
//		System.out.println(str.equals(str1));
//		System.out.println(str == str1);
//		System.out.println(str.equals(str2));
//		System.out.println(str == str2);
		
//		String str4= str.concat("amit");
//		System.out.println(str4);
		
		
//		System.out.println(str.hashCode());
//		System.out.println(str1.hashCode());
//		System.out.println(str2.hashCode());
//		System.out.println(str3.hashCode());
//		
//		StringTest st = new StringTest();
//		StringTest st1 = new StringTest();
//		System.out.println(st.hashCode());
//		System.out.println(st1.hashCode());
		
		
	}

}
