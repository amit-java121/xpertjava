package com.tibco.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.tibco.model.LoyalitySegment;
import com.tibco.service.MemberService;


@RestController
@RequestMapping("/tibco")
public class MemberController {
	
	@Autowired
	MemberService service;

	@GetMapping("/getLoyalitysegment")
	public ResponseEntity<List<LoyalitySegment>> getLoyalitySegment(@RequestParam String emailID) {
		return new ResponseEntity<List<LoyalitySegment>>(service.getLoyalitySegment(emailID), HttpStatus.OK);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleError() {
		return new ResponseEntity<String>("Record is not present for this email id", HttpStatus.NOT_FOUND);
	}

}
