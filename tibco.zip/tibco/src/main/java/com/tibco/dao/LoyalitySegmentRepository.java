package com.tibco.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tibco.model.LoyalitySegment;

@Repository
public interface LoyalitySegmentRepository extends JpaRepository<LoyalitySegment, String>{

}
