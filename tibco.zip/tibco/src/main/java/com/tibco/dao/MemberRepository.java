package com.tibco.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tibco.model.Members;

@Repository
public interface MemberRepository extends JpaRepository<Members, String>{

	Members findByemailId(String emailID);


}
