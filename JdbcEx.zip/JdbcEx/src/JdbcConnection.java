import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class JdbcConnection {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("step 1:: ");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test2","root","root");
		System.out.println("step 2:: ");
		Statement stmt = conn.createStatement();
		System.out.println("step 3:: ");
		ResultSet rs = stmt.executeQuery("select * from emp");
		
		System.out.println("step 4:: ");
		
		while(rs.next()) {
			System.out.println("id: "+rs.getString("id"));
			System.out.println("name: "+rs.getString("name"));
			System.out.println("address: "+rs.getString("address"));
		}
		
	}

}
