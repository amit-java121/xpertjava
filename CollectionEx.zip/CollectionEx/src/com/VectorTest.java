package com;

import java.util.Vector;

public class VectorTest {
	
	public static void main(String[] args) {
		Vector<String> vector = new Vector<>();
		vector.add("abc");
		vector.add("abc1");
		vector.add("abc2");
		vector.add("abc3");
		
		System.out.println(vector);
		
		vector.addElement("xyz");
		vector.addElement("pqr");
		
		System.out.println(vector);
		
		System.out.println(vector.get(1));
	}

}
