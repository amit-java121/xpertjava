package com;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTest2 {
	
	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		list.add("abc");
		list.add("abc1");
		list.add("abc2");
		list.add("abc3");
		
		System.out.println(list.size());
		
		for(String strObj:list) {
			System.out.println(strObj);
		}
		
		list.add(2, "amit");
		
		System.out.println("new size:: "+list.size());
		for(String strObj:list) {
			System.out.println(strObj);
		}
		
		
		ArrayList<String> list2 = new ArrayList<String>();
		list2.add("xyz");
		list2.add("pqr");
		
		list.addAll(1,list2);
		
		for(String strObj:list) {
			System.out.println("new "+strObj);
		}
		
		//elements remove
		list.remove(1);
		list.remove("abc3");
		
		for(String strObj:list) {
			System.out.println("remove "+strObj);
		}
		
		//list.clear();
		System.out.println("size::: "+list.subList(1,4));
		List<String> subList = list.subList(1,4);
		for(String strObj:subList) {
			System.out.println("sublist "+strObj);
		}
		
		list.set(1, "PPP");
		
		for(String strObj:list) {
			System.out.println("list "+strObj);
		}
	}

}
