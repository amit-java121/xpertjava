package sett;

import java.util.LinkedHashSet;

public class LinkedHashSetTest {
	
	public static void main(String[] args) {
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		linkedHashSet.add("test");
		linkedHashSet.add("test");
		linkedHashSet.add("test1");
		linkedHashSet.add("test2");
		linkedHashSet.add(null);
		
		System.out.println(linkedHashSet);
	}

}
