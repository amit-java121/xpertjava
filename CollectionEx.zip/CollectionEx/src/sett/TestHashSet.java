package sett;

import java.util.HashSet;

public class TestHashSet {
	
	public static void main(String[] args) {
		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("test");
		hashSet.add("test");
		hashSet.add("test1");
		hashSet.add("Test");
		hashSet.add(null);
		//hashSet.add(null);
		System.out.println(hashSet);
		
		
		HashSet<String> hashSet1 = new HashSet<>(); 
		hashSet1.add("xyz");
		hashSet1.add("pqr");
		
		hashSet.addAll(hashSet1);
		System.out.println(hashSet);
		hashSet.remove("xyz");
		System.out.println(hashSet);
		
	}

}
