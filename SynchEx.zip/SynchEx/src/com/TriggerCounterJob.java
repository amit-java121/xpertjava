package com;

public class TriggerCounterJob {
	
	public static void main(String[] args) throws InterruptedException {
		Counter counter = new Counter();
		Job1 job1 = new Job1(counter);
		job1.start();
		
		Job2 job2 = new Job2(counter);
		job2.start();
		
		
		job1.join();
		job2.join();
		
		System.out.println("count:: "+counter.count);
		
	}

}
