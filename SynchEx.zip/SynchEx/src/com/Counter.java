package com;

public class Counter {
	
	int count;
	
	public void increament() {
		///logic
		synchronized (this) {
			count++;
		}
		//logic
	}

}
