package com;

public class Job2 extends Thread{

	Counter ct;
	
	public Job2(Counter ct) {
		this.ct=ct;
	}
	
	@Override
	public void run() {
		for(int i=0;i<100000;i++) {
		   ct.increament();
		}
	}
}
