package set;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class HashSetTest {
	
	public static void main(String[] args) {
		
		Employee emp = new Employee(100, "vishal", "pune");
		Employee emp1 = new Employee(101, "vishal1", "mumbai");
		Employee emp2 = new Employee(100, "vishal", "pune");
		Employee emp3 = new Employee(103, "vishal3", "Thane");
		Employee emp4 = new Employee(104, "vishal4", "pune");
		
		HashSet<Employee> empSet = new HashSet<Employee>();
		empSet.add(emp);
		empSet.add(emp1);
		empSet.add(emp2);
		empSet.add(emp3);
		empSet.add(emp4);
		
		for (Employee employee : empSet) {
			System.out.println(employee);
		}
		
	}

}
