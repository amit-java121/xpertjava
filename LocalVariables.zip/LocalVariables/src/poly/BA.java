package poly;

public class BA extends AB{
	
	void m4(long a,long b) {
		System.out.println("BA m4() ");
	}
	
	public static void main(String[] args) {
		
		BA ba = new BA();
		ba.m4(10l, 20l);
		//ba.m4(100l, 200l);
	}

}
