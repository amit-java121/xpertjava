package poly;

public class AB {
	
	void m4(int a,int b) {
		System.out.println("AB m4() ");
	}

}
