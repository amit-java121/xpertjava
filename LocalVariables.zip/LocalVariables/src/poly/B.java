package poly;

public class B {

	public int m1(int a) {
		System.out.println("B M1():: ");
		return a;
	}
	
	public int m2(int a) {
		System.out.println("B M():: ");
		return a;
	}
}
