package poly;

public class A {
	
	int add(int a,int b) {
		
		return a+b;
	}
	
	int add(int a,int b,int c) {
		
		return a+c+b;
	}
	
	public static void main(String[] args) {
		A a = new A();
		int sum = a.add(5, 10);
		int sum2 = a.add(5, 10, 15);
		
		System.out.println(sum);
		System.out.println(sum2);
		
	}

}
