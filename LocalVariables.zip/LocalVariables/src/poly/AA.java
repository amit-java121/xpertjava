package poly;

public class AA {
	
	int aa =10;
	void m3(){
		System.out.println("AA m3() ");
	}

}
