package poly;

public class C extends B{


	public int m1(int a) {
		System.out.println("C M1()::: ");
		return a;
	}
	
	public static void main(String[] args) {
	
		B c = new C();
		c.m1(10);
		c.m2(20);
		
		
	}
}
