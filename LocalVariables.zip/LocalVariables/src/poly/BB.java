package poly;

public class BB extends AA{

	int aa=20;
	
	void m3(){
		System.out.println("BB m3() ");
	}
	
	public static void main(String[] args) {
		AA a = new BB();
		//BB b = (BB)new AA();
		System.out.println(a.aa);
		a.m3();
	}
}
