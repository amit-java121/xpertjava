package com;

public class Test1 {
	
	public int  m2() {
		System.out.println("Test1 m2()");
		int a=20;
		int b=30;
		int c =a+b;
		return c;
	}
	
	public String m3() {
		System.out.println("Test1 m3()");
		String str="xpert";
		return str;
	}
	
	public int add(int a,int b) {
		int sum =a+b;
		Test1 t = new Test1();
		t.newAdd(a);
		return sum;
	}
	
	public void newAdd(int a) {
		System.out.println("a:: "+a);
	}

}
