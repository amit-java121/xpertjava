package com;

import java.util.Scanner;

public class TestNow {
	
	int a=10;
	public static void main(String[] args) throws Exception {
		 
//		Class obj= Class.forName("com.TestNow");
//		TestNow inst = (TestNow)obj.newInstance();
//		System.out.println(inst.a);
//		
//		Scanner sc = new Scanner(System.in);
//		String str = sc.nextLine();
//		System.out.println(str);
//		String str2 = sc.nextLine();
//		System.out.println(str2);
		
		for(int i=0;i<5;i++) {
			
			for(int j=0;j>=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
