package com;

import java.util.Scanner;

public class IfElseTest {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int marks = sc.nextInt();
		
		int secondMark = sc.nextInt();
		System.out.println(secondMark);
		
		if(marks==50) {
			System.out.println("u r passed");
		}else if(marks > 60) {
			System.out.println("u r passed with ");
		}else if(secondMark > 70) {
			System.out.println("u r passed with ");
		}else {
			System.out.println(" u r failed");
		}
		
	}

}
