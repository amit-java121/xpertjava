package com;

public class B {
	
	public void test(String str) {
		if(str.equals("xpert")) {
			System.out.println("we are in xpert:: ");
		}else if(str.equals("inst")) {
			System.out.println("execute this code");
		}else {
			System.out.println("else::: ");
		}
		System.out.println("always:: ");
	}

}
