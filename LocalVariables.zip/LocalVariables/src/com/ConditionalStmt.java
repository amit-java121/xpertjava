package com;

public class ConditionalStmt {
	
	public static void main(String[] args) {
		
		B b = new B();
		b.test("xyz");
	
	}

}
