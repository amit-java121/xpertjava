package com;

public class TestAddition {

	public static void main(String[] args) {
		A a= new A();
		int sum = a.m1(10, 10);
		System.out.println("sum:: "+sum);
		
		//String str = ;
		System.out.println(a.m2());
	}
}
