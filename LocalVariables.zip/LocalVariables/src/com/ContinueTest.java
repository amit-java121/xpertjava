package com;


public class ContinueTest {

	public static void main(String[] args) {
		for(int a=0;a<5;a++) {
			if(a==2) {
				continue;
			}
			////////
			System.out.println("aa: "+a);
		}
	}
}
