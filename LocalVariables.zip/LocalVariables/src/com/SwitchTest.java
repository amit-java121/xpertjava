package com;

public class SwitchTest {
 public static void main(String[] args) {
	 int i=50;
	 switch (i) {
	case 10:
		System.out.println("abc executed");
		break;

	case 20:
		System.out.println("xyz executed");
		break;

	case 30:
		System.out.println("pqr executed");
		break;

	default:
		System.out.println("default:: ");
		break;
	}
}
}
