package com;

public class VariablesTest {
	
	int a =10;
	
	static int b=20;
	
	public int m1() {
		int c =30;
		
		return c;
	}

	
	public static void main(String[] args) {
//		VariablesTest vt = new VariablesTest();
//		System.out.println(vt.a);
//		//System.out.println(vt.b);
//		System.out.println(VariablesTest.b);
//		int result = vt.m1();
//		System.out.println(result);
		
		Test1 test = new Test1();
//		int result = test.m2();
//		System.out.println(result);
//		
//		String str = test.m3();
//		System.out.println(str);
		
		int sum = test.add(20, 80);
		 System.out.println(sum);
	}
}
