package com;

public class LoopTest {
	
	public static void main(String[] args) {
//		for(int i=0;i<10;i++) {
//			System.out.println("i:"+i);
//		}
		
//		int a=1;
//		while(a<5) {
//			System.out.println("we are inside while loop: ");
//			a++;
//		}
		int a=1;
		do {
			System.out.println("inside do loop: ");
			a++;
		}while(a>5);
	}

}
