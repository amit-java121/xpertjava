package com;

public class LocalExa {
	
	 int a = 10;
	
	
	float ft = 10.2f;
	
	public void m1() {
		int bb = 10;
	}
	
	

}
