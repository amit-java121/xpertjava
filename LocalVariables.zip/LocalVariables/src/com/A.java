package com;

public class A {
	
	public int m1(int a,int b) {
		int c=a+b;
		System.out.println("callled m1() ");
		return c;
	}
	
	public String m2() {
		//aahah
		System.out.println("callled m2() ");
		return "hello";
	}

}
