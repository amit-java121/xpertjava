package com;

public class Test {
	
	static int  vr =100;
	
	public static void main(String[] args) {
		LocalExa l = new LocalExa();
		Test t = new Test();
		int cc =l.a;
		System.out.println(cc+t.vr);
	}
}
