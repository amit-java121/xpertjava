package com;

public class LabledForLoop {
	
	public static void main(String[] args) {
	a:
		for(int i=0;i<5;i++) {
			System.out.println("first loop:");
		
			for(int j=0; j<5;j++) {
				System.out.println("second loop");
				if(j == 2) {
					System.out.println("inside if:: ");
					break a;
				}
			}
		}
	}

}
