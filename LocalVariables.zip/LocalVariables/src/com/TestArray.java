package com;

public class TestArray {

	public static void main(String[] args) {
		
		int aa[] = new int[5];
		String str[] = new String[5];
		
		str[0]="it";
		str[1]="it1";
		str[2]="it2";
		str[3]="it3";
		str[4]="it4";
		
		aa[0]=10;
		aa[1]=20;
		aa[2]=30;
		aa[3]=40;
		aa[4]=50;
		
		
		for(int i=0;i<str.length;i++) {
			System.out.println(str[4]);
		}
		
	}
}
