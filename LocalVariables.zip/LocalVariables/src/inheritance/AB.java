package inheritance;

public class AB extends A{
	
	//////
	
	public static void main(String[] args) {
		AB ab = new AB();
		ab.m1();
	}

}
