package inheritance;

public class C extends B{
	
	int c=10;
	 void m3(){
		 System.out.println();
	 }
	 
	 public static void main(String[] args) {
		C c = new C();
		c.m1();
		c.m2();
		System.out.println(c.a);
	}

}
