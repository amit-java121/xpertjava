package inheritance;

public class B extends A{
	
	int b=20;
	
	void m2() {
		System.out.println("B M1():: ");
	}
	
	public static void main(String[] args) {
		
		B b = new B();
		b.m1();
		//b.m2();
		System.out.println(b.a);
		System.out.println(b.b);
	}

}
