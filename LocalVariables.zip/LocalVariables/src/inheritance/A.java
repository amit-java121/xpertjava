package inheritance;

public class A {
	int a=10;
	
	void m1() {
		System.out.println("A m1():: ");
	}

}
