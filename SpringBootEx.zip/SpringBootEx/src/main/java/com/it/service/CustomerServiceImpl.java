package com.it.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.ICustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl {

	@Autowired
	ICustomerDao  customerDao;
	
	public Customer getUserDetails(String UserEmail,String userPass) {
		
		Customer cust = customerDao.getUserDetailsByEmailId(UserEmail);
		
		
		
		 return cust;
	}
	
	

}
