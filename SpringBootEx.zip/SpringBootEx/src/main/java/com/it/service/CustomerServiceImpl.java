package com.it.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.ICustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl {

	@Autowired
	ICustomerDao  customerDao;
	
	public Optional<Customer> getUserDetails() {
		
		 return customerDao.findById(100);
	}

}
