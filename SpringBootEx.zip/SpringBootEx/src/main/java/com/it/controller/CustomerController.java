package com.it.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.it.model.Customer;
import com.it.service.CustomerServiceImpl;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerServiceImpl customerServiceImpl;
	
	@GetMapping("/login")
	public void login(@RequestBody Customer customer) {
		
		System.out.println("we are in loginm method:: "+customer.getCustomerName()+"   "+customer.getCustomerPassword());
		Customer cust = customerServiceImpl.getUserDetails(customer.getCustomerName(),customer.getCustomerPassword());
		//List<Customer> listOfCustomer = customerServiceImpl.getUserDetails();
		System.out.println(cust.toString());
	}
	
	

}
