package com.it.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	
	@Id
	private Integer id;
	@Column(name="customerName")
	private String customerName;
	@Column(name="customerPassword")
	private String customerPassword;
	@Column(name="customerAddress")
	private String customerAddress;
	@Column(name="customerMobNumber")
	private long customerMobNumber;
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public long getCustomerMobNumber() {
		return customerMobNumber;
	}
	public void setCustomerMobNumber(long customerMobNumber) {
		this.customerMobNumber = customerMobNumber;
	}
	public Integer getCustomerId() {
		return id;
	}
	public void setCustomerId(Integer customerId) {
		this.id = customerId;
	}
	
	

}
