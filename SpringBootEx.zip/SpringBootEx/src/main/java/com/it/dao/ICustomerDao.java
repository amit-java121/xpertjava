package com.it.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.it.model.Customer;

@Repository
public interface ICustomerDao extends JpaRepository<Customer, Integer>{

	@Query("SELECT c FROM Customer c WHERE c.customerName=:userEmail")
	public Customer getUserDetailsByEmailId(@Param("userEmail") String userEmail);
}

