package com.it.dao;

import com.it.model.User;

public interface IUserLoginDao {

	public User getUserDetails(String userEmail);
	public boolean saveUser(User user);
}
