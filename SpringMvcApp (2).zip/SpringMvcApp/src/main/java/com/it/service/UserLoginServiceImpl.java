package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserLoginDao;
import com.it.model.User;

@Service
@Transactional
public class UserLoginServiceImpl implements IUserLoginService{

	@Autowired
	IUserLoginDao iUserLoginDao;
	
	@Override
	public boolean userDetails(String userEmail, String password) {
		boolean flag=false;
		System.out.println("we are in service class "+userEmail+" pass "+password);
		//UI user name
		//DB user name password
		//compare validate 
		////logic
		User user = iUserLoginDao.getUserDetails(userEmail);
		
		if(userEmail.equalsIgnoreCase(user.getUserEmail()) && password.equalsIgnoreCase(user.getPassword())) {
		 flag = true;
		}else {
		 flag=false;
		}
		
		return flag;
	}

	@Override
	public boolean saveUser(User user) {
		
		return iUserLoginDao.saveUser(user);
	}

}
