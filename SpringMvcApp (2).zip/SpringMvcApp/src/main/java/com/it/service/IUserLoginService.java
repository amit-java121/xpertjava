package com.it.service;

import com.it.model.User;

public interface IUserLoginService {
	public boolean userDetails(String userEmail,String password);
	public boolean saveUser(User user);
}
